# PYTHON QR CODE GENERATOR

## TODO
TODO:
- use fzf to select ids
- nvim config bootstrap
- makefile
  - build
  - test
- update readme
--- -------------------

## Notes/References/Questions
- docs/ directory or sphinx for project docs?



